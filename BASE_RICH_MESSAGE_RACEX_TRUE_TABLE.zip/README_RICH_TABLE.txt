RICH MESSAGE STUDIO - ORIGINAL TELEKAF TABLE BUILDER

Install: npm install
Set BOT_TOKEN and OWNER_IDS in config.js or environment variables.
Run: npm start

Commands: /start (existing base menu), /buat, /saldo, /topup, /approvecredit USER_ID JUMLAH (admin).

IMPORTANT: This patch uses @icanseeuanywhere/telekaf RichHTMLBuilder.table() in Telegram RichMessage. Credits in this simple patch are stored in memory and reset on restart; add persistent storage before production. Top-up approval is manual; verify payment yourself before running /approvecredit.
